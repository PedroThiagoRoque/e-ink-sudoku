local Validator = require("sudoku.validator")
local Solver = {}
Solver.__index = Solver
local function copy(source) local result={}; for k,v in pairs(source or {}) do result[k]=v end; return result end
function Solver.new(puzzle, values, random)
    return setmetatable({ puzzle=puzzle, values=copy(values or puzzle.givens), random=random, solutions=0, first=nil, done=false }, Solver)
end
function Solver:candidates(cell_id)
    local out = {}
    for _, value in ipairs(self.puzzle.symbols) do
        self.values[cell_id] = value
        if next(Validator.inspect(self.puzzle, self.values).conflicts) == nil then out[#out+1] = value end
    end
    self.values[cell_id] = nil
    return self.random and self.random:shuffle(out) or out
end
function Solver:search()
    if self.solutions >= 2 then return end
    local best, choices
    for _, cell_id in ipairs(self.puzzle:cell_ids()) do
        if self.values[cell_id] == nil then
            local candidate = self:candidates(cell_id)
            if #candidate == 0 then return end
            if not choices or #candidate < #choices then best, choices = cell_id, candidate end
        end
    end
    if not best then self.solutions=self.solutions+1; self.first=self.first or copy(self.values); return end
    for _, value in ipairs(choices) do self.values[best]=value; self:search(); self.values[best]=nil; if self.solutions>=2 then return end end
end
function Solver:step(_) if not self.done then self:search(); self.done=true end return self.done end
function Solver:result() return { solutions=self.solutions, solution=self.first, done=self.done } end
return Solver
