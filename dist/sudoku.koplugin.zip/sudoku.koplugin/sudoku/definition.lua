local Puzzle = require("sudoku.puzzle")
local Definition = {}
function Definition.encode(puzzle)
    local cells={}; for _,id in ipairs(puzzle:cell_ids()) do cells[#cells+1]=puzzle.cells[id] end
    return {id=puzzle.id,mode=puzzle.mode,rows=puzzle.rows,columns=puzzle.columns,symbols=puzzle.symbols,cells=cells,givens=puzzle.givens,units=puzzle.units,sums=puzzle.sums,block=puzzle.block}
end
function Definition.decode(record) return Puzzle.new(record) end
return Definition
