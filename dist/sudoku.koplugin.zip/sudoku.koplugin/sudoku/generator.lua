local Factories = require("catalog.factories")
local Puzzle = require("sudoku.puzzle")
local Random = require("sudoku.random")
local Solver = require("sudoku.solver")
local Generator = {}
Generator.__index = Generator
local regular = {
    classic={size=9, br=3, bc=3}, ["mini-4"]={size=4,br=2,bc=2}, ["mini-6"]={size=6,br=2,bc=3}, mega={size=16,br=4,bc=4},
}
local function symbols(size)
    local result={}; for i=1,size do result[i]=i<=9 and i or string.char(55+i) end; return result
end
function Generator.new(mode, difficulty, seed)
    return setmetatable({mode=mode,difficulty=difficulty or "easy",seed=seed or os.time(),random=Random.new(seed or os.time()),phase="Criando solução"},Generator)
end
function Generator:step(_)
    if self.done then return true end
    local spec = regular[self.mode] or regular.classic
    local definition = Factories.grid(self.mode.."-"..tostring(self.seed), self.mode, spec.size, spec.br, spec.bc, spec.size==16 and symbols(16) or nil)
    local shuffled = self.random:shuffle(definition.symbols)
    for row=1,spec.size do for col=1,spec.size do
        local index=((row-1)*spec.bc + math.floor((row-1)/spec.br) + col-1) % spec.size + 1
        definition.givens[row..":"..col]=shuffled[index]
    end end
    local removals = ({easy=4, medium=12, hard=24})[self.difficulty] or 4
    local ids = self.random:shuffle((function() local r={}; for _,cell in ipairs(definition.cells) do r[#r+1]=cell.id end; return r end)())
    for _, cell_id in ipairs(ids) do
        if removals <= 0 then break end
        local old = definition.givens[cell_id]
        definition.givens[cell_id] = nil
        local candidate = assert(Puzzle.new(definition))
        local solver = Solver.new(candidate)
        solver:step(100000)
        if solver:result().solutions == 1 then removals = removals - 1 else definition.givens[cell_id] = old end
    end
    self.puzzle = assert(Puzzle.new(definition)); self.phase="Concluído"; self.done=true
    return true
end
function Generator:status() return {phase=self.phase, progress=self.done and 100 or 0} end
function Generator:result() return self.done and self.puzzle or nil end
return Generator
