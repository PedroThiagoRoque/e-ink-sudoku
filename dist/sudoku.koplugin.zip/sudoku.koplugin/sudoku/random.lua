local Random = {}
Random.__index = Random
function Random.new(seed) return setmetatable({ state = (tonumber(seed) or 1) % 2147483647 }, Random) end
function Random:next_int(limit)
    self.state = (self.state * 48271) % 2147483647
    return (self.state % limit) + 1
end
function Random:shuffle(values)
    local copy = {}; for i, value in ipairs(values) do copy[i] = value end
    for i = #copy, 2, -1 do local j = self:next_int(i); copy[i], copy[j] = copy[j], copy[i] end
    return copy
end
return Random
