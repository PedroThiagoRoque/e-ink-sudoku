package.path = "sudoku.koplugin/?.lua;sudoku.koplugin/?/init.lua;" .. package.path
local Test = require("tests.testlib")
local Controller = require("sudoku.generation_controller")
Test.run({
    ["does not complete after cancellation"] = function()
        local completed = false
        local generator = { step=function() return false end, status=function() return {phase="Criando"} end }
        local controller = Controller.new(generator, {completed=function() completed=true end})
        controller:cancel(); controller:step()
        Test.falsy(completed)
        Test.truthy(controller.cancelled)
    end,
    ["notifies completion after generator finishes"] = function()
        local completed = false
        local generator = { step=function() return true end, result=function() return {id="x"} end, status=function() return {phase="Concluído"} end }
        local controller = Controller.new(generator, {completed=function() completed=true end})
        controller:step()
        Test.truthy(completed)
    end,
})
