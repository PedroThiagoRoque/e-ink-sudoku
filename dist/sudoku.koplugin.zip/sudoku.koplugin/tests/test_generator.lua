package.path = "sudoku.koplugin/?.lua;sudoku.koplugin/?/init.lua;" .. package.path
local Test = require("tests.testlib")
local Generator = require("sudoku.generator")
Test.run({
    ["generates the same classic puzzle from the same seed"] = function()
        local a, b = Generator.new("classic", "easy", 17), Generator.new("classic", "easy", 17)
        a:step(100); b:step(100)
        local pa, pb = assert(a:result()), assert(b:result())
        Test.equal(pa.id, pb.id)
        Test.equal(pa.givens["1:1"], pb.givens["1:1"])
    end,
    ["generates a challenge with one solution"] = function()
        local generator = Generator.new("mini-4", "easy", 2)
        generator:step(100)
        local puzzle = assert(generator:result())
        Test.truthy(puzzle.givens["1:1"])
    end,
})
