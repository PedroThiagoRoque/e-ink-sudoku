package.path = "sudoku.koplugin/?.lua;sudoku.koplugin/?/init.lua;" .. package.path
local Test = require("tests.testlib")
local Puzzle = require("sudoku.puzzle")
local Solver = require("sudoku.solver")
local function p(givens)
    return assert(Puzzle.new({id="solver", symbols={1,2}, cells={{id="a"},{id="b"}}, units={{cells={"a","b"}}}, givens=givens or {}}))
end
Test.run({
    ["stops counting after a second solution"] = function()
        local solver = Solver.new(p())
        solver:step(100)
        Test.equal(solver:result().solutions, 2)
    end,
    ["finds a unique solved puzzle"] = function()
        local solver = Solver.new(p({a=1,b=2}))
        solver:step(100)
        Test.equal(solver:result().solutions, 1)
    end,
})
