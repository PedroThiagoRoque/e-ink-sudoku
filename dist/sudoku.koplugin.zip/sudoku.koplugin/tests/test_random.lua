package.path = "sudoku.koplugin/?.lua;sudoku.koplugin/?/init.lua;" .. package.path
local Test = require("tests.testlib")
local Random = require("sudoku.random")
Test.run({
    ["repeats the same sequence for the same seed"] = function()
        local a, b = Random.new(123), Random.new(123)
        Test.equal(a:next_int(1000), b:next_int(1000))
        Test.equal(a:next_int(1000), b:next_int(1000))
    end,
    ["shuffles reproducibly"] = function()
        local a, b = Random.new(3), Random.new(3)
        Test.equal(table.concat(a:shuffle({1,2,3,4})), table.concat(b:shuffle({1,2,3,4})))
    end,
})
